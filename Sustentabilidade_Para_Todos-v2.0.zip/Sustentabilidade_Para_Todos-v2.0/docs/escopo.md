# Escopo do projeto: Sustentabilidade para Todos

## 1. Problema

Muita gente quer ajudar o meio ambiente, mas não sabe por onde começar. A informação costuma vir em linguagem difícil ou em sites que **não são acessíveis** para pessoas com deficiência (sem descrição nas imagens, com pouco contraste e sem navegação pelo teclado).

## 2. Público-alvo

- Moradores do bairro e famílias que querem hábitos mais sustentáveis
- Estudantes e escolas
- **Pessoas com deficiência** (visual, motora e baixa visão) e pessoas idosas, que precisam de letra maior, alto contraste e navegação pelo teclado
- Voluntários e parceiros que querem apoiar o projeto

## 3. ODS ligados ao projeto (ONU, Agenda 2030)

| ODS | Como o site contribui |
|---|---|
| 6: Água potável e saneamento | Página Água com calculadora do banho e dicas de economia |
| 7: Energia limpa e acessível | Página Energia com dicas e checklist de hábitos |
| 10: Redução das desigualdades | Site acessível para pessoas com deficiência |
| 11: Cidades e comunidades sustentáveis | Coleta seletiva, parceiros do bairro, voluntariado |
| 12: Consumo e produção responsáveis | Página Plástico, descarte correto e reaproveitamento |

## 4. Objetivo geral

Criar um site simples e acessível que ensine atitudes sustentáveis do dia a dia e aproxime a comunidade do projeto por meio de voluntariado e apoio.

## 5. Objetivos específicos (mensuráveis)

| # | Objetivo | Critério de aceitação | Status |
|---|---|---|---|
| 1 | Ter 10 páginas interligadas com a mesma identidade visual | 10 páginas com o mesmo menu e o mesmo `estilo.css`, sem link quebrado | ✅ Entregue |
| 2 | Receber contatos e voluntários pelo site | Formulário com validação em JS, mensagens de erro e confirmação de envio | ✅ Entregue |
| 3 | Oferecer uma forma de apoio ou doação | Área "Apoie o projeto" com formulário validado | ✅ Entregue |
| 4 | Garantir acessibilidade | Zero erros no W3C, contraste AA, `alt` nas imagens, navegação por teclado e alto contraste em todas as páginas | ✅ Entregue |
| 5 | Funcionar no celular e no computador | Nenhuma página com rolagem lateral na largura de 375 px | ✅ Entregue |
| 6 | Publicar o site com HTTPS | Site abrindo por URL pública com HTTPS | ✅ https://sustentabilidadeparatodos.up.railway.app/ |

## 6. Fora do escopo

- Pagamento real de doações (o formulário só registra o interesse, porque é um projeto acadêmico)
- Envio real de e-mail pelo formulário (não há servidor de e-mail)
- Login de usuários e banco de dados
